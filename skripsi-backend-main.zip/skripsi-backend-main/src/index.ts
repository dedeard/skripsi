import './alias'
import Application from '@/app'

const app = new Application()

// Run Application
app.listen()
