import alias from 'module-alias'
import path from 'path'

alias.addAliases({
  '@': path.join(__dirname),
})
