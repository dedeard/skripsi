export const READ_ROLE = 'Read Role'
export const CREATE_ROLE = 'Create Role'
export const UPDATE_ROLE = 'Update Role'
export const DELETE_ROLE = 'Delete Role'

export const READ_USER = 'Read User'
export const CREATE_USER = 'Create User'
export const UPDATE_USER = 'Update User'
export const DELETE_USER = 'Delete User'

export const READ_ALBUM = 'Read Album'
export const CREATE_ALBUM = 'Create Album'
export const UPDATE_ALBUM = 'Update Album'
export const DELETE_ALBUM = 'Delete Album'

export const READ_MEDIA = 'Read Media'
export const CREATE_MEDIA = 'Create Media'
export const UPDATE_MEDIA = 'Update Media'
export const DELETE_MEDIA = 'Delete Media'
